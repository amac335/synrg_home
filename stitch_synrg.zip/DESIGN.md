---
name: The Grounded Architect
colors:
  surface: '#141312'
  surface-dim: '#141312'
  surface-bright: '#3a3938'
  surface-container-lowest: '#0f0e0d'
  surface-container-low: '#1c1b1a'
  surface-container: '#201f1e'
  surface-container-high: '#2b2a29'
  surface-container-highest: '#363433'
  on-surface: '#e6e2df'
  on-surface-variant: '#d6c3b9'
  inverse-surface: '#e6e2df'
  inverse-on-surface: '#31302f'
  outline: '#9f8d85'
  outline-variant: '#52443d'
  surface-tint: '#fbb893'
  primary: '#fbb893'
  on-primary: '#4e250b'
  primary-container: '#be8362'
  on-primary-container: '#461f05'
  inverse-primary: '#855234'
  secondary: '#b7c7eb'
  on-secondary: '#20304e'
  secondary-container: '#3a4968'
  on-secondary-container: '#a9b8dd'
  tertiary: '#93cdf5'
  on-tertiary: '#00344c'
  tertiary-container: '#5d97bd'
  on-tertiary-container: '#002d42'
  error: '#ffb4ab'
  on-error: '#690005'
  error-container: '#93000a'
  on-error-container: '#ffdad6'
  primary-fixed: '#ffdbc9'
  primary-fixed-dim: '#fbb893'
  on-primary-fixed: '#331200'
  on-primary-fixed-variant: '#693b1f'
  secondary-fixed: '#d7e2ff'
  secondary-fixed-dim: '#b7c7eb'
  on-secondary-fixed: '#091b37'
  on-secondary-fixed-variant: '#374765'
  tertiary-fixed: '#c7e7ff'
  tertiary-fixed-dim: '#93cdf5'
  on-tertiary-fixed: '#001e2e'
  on-tertiary-fixed-variant: '#004c6c'
  background: '#141312'
  on-background: '#e6e2df'
  surface-variant: '#363433'
typography:
  display-lg:
    fontFamily: Public Sans
    fontSize: 3.5rem
    fontWeight: '700'
    lineHeight: '1.1'
    letterSpacing: -0.02em
  headline-md:
    fontFamily: Public Sans
    fontSize: 1.75rem
    fontWeight: '600'
    lineHeight: '1.2'
  body-lg:
    fontFamily: Inter
    fontSize: 1rem
    fontWeight: '400'
    lineHeight: '1.5'
  label-sm:
    fontFamily: Inter
    fontSize: 0.6875rem
    fontWeight: '500'
    lineHeight: '1.2'
    letterSpacing: 0.05em
rounded:
  sm: 0.125rem
  DEFAULT: 0.25rem
  md: 0.375rem
  lg: 0.5rem
  xl: 0.75rem
  full: 9999px
spacing:
  base: 8px
  xs: 4px
  sm: 8px
  md: 16px
  lg: 24px
  xl: 32px
  section: 64px
---

# Design System Specification: Technical Grounding & Atmospheric Depth

## 1. Overview & Creative North Star

### The Creative North Star: "The Grounded Architect"
This design system rejects the sterile, "off-the-shelf" aesthetic of modern SaaS in favor of a **High-End Editorial** experience. It is built for environments where engineering precision meets legacy trust. We call this aesthetic "The Grounded Architect"—a visual language that feels as heavy as bronze and as expansive as the ether.

To break the "template" look, designers must embrace **Intentional Asymmetry**. Avoid perfectly centered hero sections; instead, use the high-contrast typography scale to create overlapping layers where text bleeds into image containers. This system moves away from a rigid grid toward a curated, layered composition that feels more like a technical journal than a generic dashboard. The use of soft, subtle rounding adds a layer of disciplined refinement to this architectural foundation.

---

## 2. Color & Tonal Architecture

The palette is a sophisticated interplay between the warmth of earth (Copper/Bronze) and the vastness of the ether (Deep Blue).

### The "No-Line" Rule
**Standard 1px borders are strictly prohibited for sectioning.** To define boundaries, you must use background color shifts. 
- A section using `surface_container_low` (#1c1b1a) should sit directly against the `background` (#141312).
- Use `spacing-16` or `spacing-24` to allow these tonal shifts to breathe.

### Surface Hierarchy & Nesting
Treat the UI as a physical stack of materials. 
- **Base Layer:** `surface` (#141312)
- **Secondary Sections:** `surface_container_low` (#1c1b1a)
- **Interactive Cards:** `surface_container` (#201f1e) or `surface_container_high` (#2b2a29)
- **Elevated Modals:** `surface_container_highest` (#363433)

### The "Glass & Gradient" Rule
To add "soul" to the technical precision, main CTAs and hero backgrounds should utilize a subtle linear gradient transitioning from `primary` (#A66E4E) to `primary_container` at a 135-degree angle. Floating elements (like navigation bars or context menus) should use **Glassmorphism**: a semi-transparent `surface_variant` with a 20px backdrop-blur.

---

## 3. Typography

The typography strategy pairs the strong, authoritative **Public Sans** for high-impact headlines with the hyper-legible **Inter** for body copy, technical metadata, and labels.

*   **Display & Headlines (Public Sans):** Used for "The Statement." These should be set with tight letter-spacing (-2%) to feel like a solid architectural block.
*   **Body & Titles (Inter):** Provides the "Technical Clarity." By switching to Inter for body copy, the system ensures that long-form technical descriptions remain neutral and highly readable against complex layouts.
*   **Labels & Metadata (Inter):** Introduces a neutral, Swiss-style precision for functional data, ensuring micro-copy remains legible even at the smallest scales.

**Scale Highlights:**
- **Display-LG:** 3.5rem (Public Sans) — For singular, high-impact statements.
- **Headline-MD:** 1.75rem (Public Sans) — For section headers.
- **Body-LG:** 1rem (Inter) — Primary reading weight for technical documentation.
- **Label-SM:** 0.6875rem (Inter) — For technical metadata and micro-copy.

---

## 4. Elevation & Depth

Hierarchy is achieved through **Tonal Layering** rather than traditional drop shadows.

### The Layering Principle
Depth is created by "stacking." Place a `surface_container_lowest` (#1A1918) element inside a `surface_container_high` (#2b2a29) area to create a recessed, "etched" look.

### Ambient Shadows
If a floating effect is mandatory (e.g., a primary modal):
- **Blur:** 40px - 60px.
- **Opacity:** 6% - 10%.
- **Color:** Use a tinted version of `on_secondary_fixed` (#091b37) to mimic natural atmospheric scattering rather than a dead grey shadow.

### The "Ghost Border" Fallback
If accessibility requires a container outline, use a **Ghost Border**: `outline_variant` (#52443d) at **15% opacity**. This provides a hint of structure without breaking the seamless tonal flow.

---

## 5. Components

### Buttons
- **Primary:** Gradient fill (`primary` to `primary_container`). Text in `on_primary_fixed`. 
- **Secondary:** `surface_container_highest` background with a `primary` Ghost Border.
- **Shape:** Use **Soft corners** (0.25rem / 4px radius) for a precise, machined look that balances the bold typography.

### Chips & Technical Tags
- Use `secondary_container` (#1B2B48) with text in `on_secondary_container`.
- Standard soft-cornered radius (0.25rem) for labels in `label-sm` (Inter) to denote "System Status."

### Inputs & Fields
- **Background:** `surface_container_lowest` (#1A1918).
- **Shape:** Softened edges (0.25rem radius).
- **Active State:** A 1px bottom-only border using `primary` (#A66E4E). Do not box the entire input.

### Cards & Lists
- **The No-Divider Mandate:** Forbid horizontal lines. Separate list items using vertical whitespace or an alternating tonal shift between `surface` and `surface_container_low`.
- **Shape:** 0.5rem (rounded-lg) corner radius for all cards to maintain the sophisticated hardware aesthetic.
- **Engineering Data:** Use `tertiary` (#4E89AE) for data visualization and "Ether" elements (charts, sparks, status indicators).

---

## 6. Do's and Don't's

### Do:
- **Do** use negative space as a structural element. A 64px (spacing-section) gap is often more effective than a line.
- **Do** use disciplined, soft corners (roundedness: 1) for interactive elements to maintain architectural precision.
- **Do** overlap elements. Let a `display-lg` headline sit 20px over the edge of a card to create editorial depth.
- **Do** use `primary_fixed_dim` for icons to give them a warm, metallic glow against the dark background.

### Don't:
- **Don't** use pill-shaped or overly rounded elements. The system uses a **Soft** (roundedness: 1) language; excessive curves will feel too "soft" for this architectural aesthetic.
- **Don't** use sharp corners. Complete 90-degree angles feel too aggressive and lack the "machined" refinement of the soft radius.
- **Don't** use pure black (#000000) or pure white (#FFFFFF). Use the provided `surface` and `on_surface` tokens to maintain the "Grounded" warmth.
- **Don't** use standard "Material Design" shadows. They feel too digital and "cheap" for this system.
- **Don't** use 100% opaque borders. They create "visual noise" that contradicts the high-end editorial goal.